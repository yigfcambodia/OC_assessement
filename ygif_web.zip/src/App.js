import React from 'react';
import './App.css';
import heroImage from '/Users/keomunin/Documents/z_React/ygif-web/src/images/heroImage.jpg'; 

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div className="logo">Logo</div>
        <div className="nav-wrapper">
          <nav className="nav-links">
            <a href="#">Link 1</a>
            <a href="#">Link 2</a>
            <a href="#">Link 3</a>
            <a href="#">Link 4</a>
            <a href="#">Link 5</a>
          </nav>
          <button className="header-button">Button</button>
        </div>
      </header>
      <section className="hero">
        <div className="hero-content">
          <h1>Great design is invisible</h1>
          <p>Lorem ipsum dolor sit amet constreteur</p>
          <button className="hero-button">Button</button>
        </div>
        <div className="hero-image" style={{ backgroundImage: `url(${heroImage})` }}></div>
      </section>
      <section className="latest-blog">
        <h2>Latest Blog</h2>
        <div className="blog-cards">
          <div className="blog-card">
            <div className="blog-image"></div>
            <h3>Humans are much more smarter than AI</h3>
            <p>Lorem ipsum dolor sit amet consectetur. Lorem ipsum dolor sit amet consectetur.</p>
            <a href="#" className="learn-more">Learn more</a>
          </div>
          <div className="blog-card">
            <div className="blog-image"></div>
            <h3>Humans are much more smarter than AI</h3>
            <p>Lorem ipsum dolor sit amet consectetur. Lorem ipsum dolor sit amet consectetur.</p>
            <a href="#" className="learn-more">Learn more</a>
          </div>
          <div className="blog-card">
            <div className="blog-image"></div>
            <h3>Humans are much more smarter than AI</h3>
            <p>Lorem ipsum dolor sit amet consectetur. Lorem ipsum dolor sit amet consectetur.</p>
            <a href="#" className="learn-more">Learn more</a>
          </div>
        </div>
        <button className="blog-button">Button</button>
      </section>
      <section className="business-strategy">
        <h2>Our business strategy has helped many businesses across the globe</h2>
        <p>Lorem ipsum dolor sit amet consectetur. Elementum nisl duis tortor sed. Suspendisse lobortis vitae quis vehicula pellentesque sit id</p>
        <div className="strategy-image"></div>
      </section>
    </div>
  );
}

export default App;
