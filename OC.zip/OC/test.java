public static boolean validateForm(String name, String email) {
    if (name.isEmpty() || email.isEmpty()) {
        return false;
    }

    if (!email.contains("@")) {
        return false;
    }

    return true;
}